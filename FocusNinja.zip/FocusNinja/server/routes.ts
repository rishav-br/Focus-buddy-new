import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertGoalSchema, insertTimerSessionSchema, insertAiSuggestionSchema } from "@shared/schema";
import OpenAI from "openai";

const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Mock user ID for demo - in real app this would come from session/auth
  const DEMO_USER_ID = 1;

  // Goals routes
  app.get("/api/goals", async (req, res) => {
    try {
      const goals = await storage.getGoals(DEMO_USER_ID);
      res.json(goals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch goals" });
    }
  });

  app.post("/api/goals", async (req, res) => {
    try {
      const goalData = insertGoalSchema.parse(req.body);
      const goal = await storage.createGoal({ ...goalData, userId: DEMO_USER_ID });
      res.json(goal);
    } catch (error) {
      res.status(400).json({ message: "Invalid goal data" });
    }
  });

  app.put("/api/goals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertGoalSchema.partial().parse(req.body);
      const goal = await storage.updateGoal(id, updates);
      
      if (!goal) {
        return res.status(404).json({ message: "Goal not found" });
      }
      
      res.json(goal);
    } catch (error) {
      res.status(400).json({ message: "Invalid update data" });
    }
  });

  app.delete("/api/goals/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const deleted = await storage.deleteGoal(id);
      
      if (!deleted) {
        return res.status(404).json({ message: "Goal not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to delete goal" });
    }
  });

  // Timer sessions routes
  app.get("/api/timer-sessions", async (req, res) => {
    try {
      const sessions = await storage.getTimerSessions(DEMO_USER_ID);
      res.json(sessions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch timer sessions" });
    }
  });

  app.post("/api/timer-sessions", async (req, res) => {
    try {
      const sessionData = insertTimerSessionSchema.parse(req.body);
      const session = await storage.createTimerSession({ ...sessionData, userId: DEMO_USER_ID });
      res.json(session);
    } catch (error) {
      res.status(400).json({ message: "Invalid session data" });
    }
  });

  // AI suggestions routes
  app.get("/api/ai-suggestions", async (req, res) => {
    try {
      const suggestions = await storage.getAiSuggestions(DEMO_USER_ID);
      res.json(suggestions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch AI suggestions" });
    }
  });

  app.post("/api/ai-suggestions/generate", async (req, res) => {
    try {
      const { context } = req.body;
      
      // Get user's recent goals and timer sessions for context
      const goals = await storage.getGoals(DEMO_USER_ID);
      const sessions = await storage.getTimerSessions(DEMO_USER_ID);
      
      const contextString = `
        User's active goals: ${goals.map(g => `${g.title} (${g.progress}% complete)`).join(', ')}
        Recent timer sessions: ${sessions.slice(-5).map(s => `${s.duration}min ${s.type}`).join(', ')}
        Additional context: ${context || 'general productivity advice'}
      `;

      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are Focus Buddy, a friendly AI productivity companion. Provide personalized, encouraging productivity tips in JSON format. Be specific, actionable, and motivational. Respond with JSON in this format: { 'content': string, 'category': string }"
          },
          {
            role: "user",
            content: `Based on this user context, give me a personalized productivity tip: ${contextString}`
          }
        ],
        response_format: { type: "json_object" },
      });

      const aiResponse = JSON.parse(response.choices[0].message.content || '{}');
      
      const suggestion = await storage.createAiSuggestion({
        userId: DEMO_USER_ID,
        content: aiResponse.content || "Keep up the great work! Small consistent steps lead to big achievements.",
        category: aiResponse.category || "motivation",
        isHelpful: null,
        isSaved: false
      });

      res.json(suggestion);
    } catch (error) {
      console.error("AI suggestion error:", error);
      // Fallback suggestion if AI fails
      const fallbackSuggestion = await storage.createAiSuggestion({
        userId: DEMO_USER_ID,
        content: "Try the 2-minute rule: if a task takes less than 2 minutes, do it right away instead of adding it to your todo list.",
        category: "productivity",
        isHelpful: null,
        isSaved: false
      });
      res.json(fallbackSuggestion);
    }
  });

  app.put("/api/ai-suggestions/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = insertAiSuggestionSchema.partial().parse(req.body);
      const suggestion = await storage.updateAiSuggestion(id, updates);
      
      if (!suggestion) {
        return res.status(404).json({ message: "Suggestion not found" });
      }
      
      res.json(suggestion);
    } catch (error) {
      res.status(400).json({ message: "Invalid update data" });
    }
  });

  // Chat with AI endpoint
  app.post("/api/ai-chat", async (req, res) => {
    try {
      const { message } = req.body;
      
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      const response = await openai.chat.completions.create({
        model: "gpt-4o",
        messages: [
          {
            role: "system",
            content: "You are Focus Buddy, a friendly AI productivity companion. Help users with productivity questions, time management, goal setting, and motivation. Be encouraging, specific, and actionable in your responses."
          },
          {
            role: "user",
            content: message
          }
        ],
      });

      const aiResponse = response.choices[0].message.content;
      res.json({ response: aiResponse });
    } catch (error) {
      console.error("AI chat error:", error);
      res.status(500).json({ 
        response: "I'm having trouble connecting right now, but here's a quick tip: Break down big tasks into smaller, manageable steps. You've got this! 💪"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
