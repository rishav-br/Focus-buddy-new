import { 
  users, goals, timerSessions, aiSuggestions,
  type User, type InsertUser, 
  type Goal, type InsertGoal,
  type TimerSession, type InsertTimerSession,
  type AiSuggestion, type InsertAiSuggestion
} from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Goal methods
  getGoals(userId: number): Promise<Goal[]>;
  getGoal(id: number): Promise<Goal | undefined>;
  createGoal(goal: InsertGoal & { userId: number }): Promise<Goal>;
  updateGoal(id: number, updates: Partial<InsertGoal>): Promise<Goal | undefined>;
  deleteGoal(id: number): Promise<boolean>;
  
  // Timer session methods
  getTimerSessions(userId: number): Promise<TimerSession[]>;
  createTimerSession(session: InsertTimerSession & { userId: number }): Promise<TimerSession>;
  
  // AI suggestion methods
  getAiSuggestions(userId: number): Promise<AiSuggestion[]>;
  createAiSuggestion(suggestion: InsertAiSuggestion & { userId: number }): Promise<AiSuggestion>;
  updateAiSuggestion(id: number, updates: Partial<InsertAiSuggestion>): Promise<AiSuggestion | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private goals: Map<number, Goal>;
  private timerSessions: Map<number, TimerSession>;
  private aiSuggestions: Map<number, AiSuggestion>;
  private currentUserId: number;
  private currentGoalId: number;
  private currentTimerSessionId: number;
  private currentAiSuggestionId: number;

  constructor() {
    this.users = new Map();
    this.goals = new Map();
    this.timerSessions = new Map();
    this.aiSuggestions = new Map();
    this.currentUserId = 1;
    this.currentGoalId = 1;
    this.currentTimerSessionId = 1;
    this.currentAiSuggestionId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getGoals(userId: number): Promise<Goal[]> {
    return Array.from(this.goals.values()).filter(goal => goal.userId === userId);
  }

  async getGoal(id: number): Promise<Goal | undefined> {
    return this.goals.get(id);
  }

  async createGoal(goalData: InsertGoal & { userId: number }): Promise<Goal> {
    const id = this.currentGoalId++;
    const goal: Goal = {
      id,
      userId: goalData.userId,
      title: goalData.title,
      description: goalData.description || null,
      category: goalData.category,
      priority: goalData.priority,
      progress: goalData.progress || 0,
      targetValue: goalData.targetValue || 100,
      deadline: goalData.deadline || null,
      isCompleted: goalData.isCompleted || false,
      createdAt: new Date(),
    };
    this.goals.set(id, goal);
    return goal;
  }

  async updateGoal(id: number, updates: Partial<InsertGoal>): Promise<Goal | undefined> {
    const goal = this.goals.get(id);
    if (!goal) return undefined;
    
    const updatedGoal = { ...goal, ...updates };
    this.goals.set(id, updatedGoal);
    return updatedGoal;
  }

  async deleteGoal(id: number): Promise<boolean> {
    return this.goals.delete(id);
  }

  async getTimerSessions(userId: number): Promise<TimerSession[]> {
    return Array.from(this.timerSessions.values()).filter(session => session.userId === userId);
  }

  async createTimerSession(sessionData: InsertTimerSession & { userId: number }): Promise<TimerSession> {
    const id = this.currentTimerSessionId++;
    const session: TimerSession = {
      ...sessionData,
      id,
      completedAt: new Date(),
    };
    this.timerSessions.set(id, session);
    return session;
  }

  async getAiSuggestions(userId: number): Promise<AiSuggestion[]> {
    return Array.from(this.aiSuggestions.values()).filter(suggestion => suggestion.userId === userId);
  }

  async createAiSuggestion(suggestionData: InsertAiSuggestion & { userId: number }): Promise<AiSuggestion> {
    const id = this.currentAiSuggestionId++;
    const suggestion: AiSuggestion = {
      id,
      userId: suggestionData.userId,
      content: suggestionData.content,
      category: suggestionData.category,
      isHelpful: suggestionData.isHelpful ?? null,
      isSaved: suggestionData.isSaved || false,
      createdAt: new Date(),
    };
    this.aiSuggestions.set(id, suggestion);
    return suggestion;
  }

  async updateAiSuggestion(id: number, updates: Partial<InsertAiSuggestion>): Promise<AiSuggestion | undefined> {
    const suggestion = this.aiSuggestions.get(id);
    if (!suggestion) return undefined;
    
    const updatedSuggestion = { ...suggestion, ...updates };
    this.aiSuggestions.set(id, updatedSuggestion);
    return updatedSuggestion;
  }
}

export const storage = new MemStorage();
