// Client-side storage utilities for persisting user data locally

interface StorageData {
  goals: any[];
  timerSessions: any[];
  preferences: {
    theme: 'light' | 'dark';
    timerDuration: number;
    shortBreakDuration: number;
    longBreakDuration: number;
    autoStartBreaks: boolean;
    soundEnabled: boolean;
  };
}

const DEFAULT_DATA: StorageData = {
  goals: [],
  timerSessions: [],
  preferences: {
    theme: 'light',
    timerDuration: 25,
    shortBreakDuration: 5,
    longBreakDuration: 15,
    autoStartBreaks: false,
    soundEnabled: true,
  }
};

export class LocalStorage {
  private static readonly STORAGE_KEY = 'focus-buddy-data';

  static getData(): StorageData {
    try {
      const stored = localStorage.getItem(this.STORAGE_KEY);
      if (stored) {
        return { ...DEFAULT_DATA, ...JSON.parse(stored) };
      }
    } catch (error) {
      console.error('Error reading from localStorage:', error);
    }
    return DEFAULT_DATA;
  }

  static setData(data: Partial<StorageData>): void {
    try {
      const current = this.getData();
      const updated = { ...current, ...data };
      localStorage.setItem(this.STORAGE_KEY, JSON.stringify(updated));
    } catch (error) {
      console.error('Error writing to localStorage:', error);
    }
  }

  static updatePreferences(preferences: Partial<StorageData['preferences']>): void {
    const current = this.getData();
    this.setData({
      ...current,
      preferences: { ...current.preferences, ...preferences }
    });
  }

  static addTimerSession(session: any): void {
    const current = this.getData();
    this.setData({
      ...current,
      timerSessions: [...current.timerSessions, { ...session, id: Date.now() }]
    });
  }

  static getTimerStats() {
    const data = this.getData();
    const today = new Date().toDateString();
    const todaySessions = data.timerSessions.filter((session: any) => {
      return new Date(session.completedAt).toDateString() === today;
    });

    const totalFocusTime = todaySessions
      .filter((session: any) => session.type === 'work')
      .reduce((total: number, session: any) => total + session.duration, 0);

    return {
      todaySessions: todaySessions.length,
      totalFocusTime,
      totalSessions: data.timerSessions.length
    };
  }

  static clear(): void {
    try {
      localStorage.removeItem(this.STORAGE_KEY);
    } catch (error) {
      console.error('Error clearing localStorage:', error);
    }
  }
}
