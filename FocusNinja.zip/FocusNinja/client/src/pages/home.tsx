import LoadingScreen from "@/components/loading-screen";
import Navbar from "@/components/navbar";
import HeroSection from "@/components/hero-section";
import FocusTimer from "@/components/focus-timer";
import GoalTracker from "@/components/goal-tracker";
import AiSuggestions from "@/components/ai-suggestions";
import FeaturesGrid from "@/components/features-grid";
import Footer from "@/components/footer";
import QuickNav from "@/components/quick-nav";
import { useEffect, useState } from "react";

export default function Home() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <div className="min-h-screen">
      <Navbar />
      <HeroSection />
      <FocusTimer />
      <GoalTracker />
      <AiSuggestions />
      <FeaturesGrid />
      <Footer />
      <QuickNav />
    </div>
  );
}
