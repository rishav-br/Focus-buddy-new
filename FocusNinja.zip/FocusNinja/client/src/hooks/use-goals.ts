import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Goal, InsertGoal } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useGoals() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: goals = [], isLoading, error } = useQuery<Goal[]>({
    queryKey: ['/api/goals']
  });

  const createGoalMutation = useMutation({
    mutationFn: async (goalData: InsertGoal) => {
      const response = await apiRequest('POST', '/api/goals', goalData);
      return response.json();
    },
    onSuccess: (newGoal) => {
      queryClient.invalidateQueries({ queryKey: ['/api/goals'] });
      toast({
        title: "Goal created!",
        description: `"${newGoal.title}" has been added to your goals.`,
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error creating goal",
        description: error.message || "Failed to create goal. Please try again.",
        variant: "destructive",
      });
    }
  });

  const updateGoalMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<InsertGoal> }) => {
      const response = await apiRequest('PUT', `/api/goals/${id}`, updates);
      return response.json();
    },
    onSuccess: (updatedGoal) => {
      queryClient.invalidateQueries({ queryKey: ['/api/goals'] });
      
      // Show celebration if goal is completed
      if (updatedGoal.isCompleted) {
        toast({
          title: "🎉 Goal completed!",
          description: `Congratulations on completing "${updatedGoal.title}"!`,
        });
      }
    },
    onError: (error: any) => {
      toast({
        title: "Error updating goal",
        description: error.message || "Failed to update goal. Please try again.",
        variant: "destructive",
      });
    }
  });

  const deleteGoalMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/goals/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/goals'] });
      toast({
        title: "Goal deleted",
        description: "Goal has been removed from your list.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error deleting goal",
        description: error.message || "Failed to delete goal. Please try again.",
        variant: "destructive",
      });
    }
  });

  const createGoal = (goalData: InsertGoal) => {
    createGoalMutation.mutate(goalData);
  };

  const updateGoal = (id: number, updates: Partial<InsertGoal>) => {
    updateGoalMutation.mutate({ id, updates });
  };

  const deleteGoal = (id: number) => {
    deleteGoalMutation.mutate(id);
  };

  // Calculate statistics
  const stats = {
    total: goals.length,
    completed: goals.filter(goal => goal.isCompleted).length,
    inProgress: goals.filter(goal => !goal.isCompleted && goal.progress > 0).length,
    notStarted: goals.filter(goal => goal.progress === 0).length,
    averageProgress: goals.length > 0 ? 
      Math.round(goals.reduce((sum, goal) => sum + goal.progress, 0) / goals.length) : 0
  };

  return {
    goals,
    isLoading,
    error,
    createGoal,
    updateGoal,
    deleteGoal,
    stats,
    isCreating: createGoalMutation.isPending,
    isUpdating: updateGoalMutation.isPending,
    isDeleting: deleteGoalMutation.isPending
  };
}
