import { useState, useEffect, useCallback } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { LocalStorage } from "@/lib/storage";
import { useToast } from "@/hooks/use-toast";

type TimerMode = 'work' | 'short_break' | 'long_break';

interface TimerPreferences {
  workDuration: number;
  shortBreakDuration: number;
  longBreakDuration: number;
  autoStartBreaks: boolean;
  soundEnabled: boolean;
}

export function useTimer() {
  const [minutes, setMinutes] = useState(25);
  const [seconds, setSeconds] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState<TimerMode>('work');
  const [sessionsCompleted, setSessionsCompleted] = useState(0);
  const [initialMinutes, setInitialMinutes] = useState(25);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Load preferences on mount
  useEffect(() => {
    const data = LocalStorage.getData();
    const workDuration = data.preferences.timerDuration;
    setMinutes(workDuration);
    setInitialMinutes(workDuration);
  }, []);

  // Timer countdown logic
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isRunning && (minutes > 0 || seconds > 0)) {
      interval = setInterval(() => {
        if (seconds > 0) {
          setSeconds(seconds - 1);
        } else if (minutes > 0) {
          setMinutes(minutes - 1);
          setSeconds(59);
        }
      }, 1000);
    } else if (isRunning && minutes === 0 && seconds === 0) {
      // Timer completed
      handleTimerComplete();
    }

    return () => clearInterval(interval);
  }, [isRunning, minutes, seconds]);

  const saveSessionMutation = useMutation({
    mutationFn: async (sessionData: { duration: number; type: TimerMode }) => {
      const response = await apiRequest('POST', '/api/timer-sessions', sessionData);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/timer-sessions'] });
    }
  });

  const handleTimerComplete = useCallback(() => {
    setIsRunning(false);
    
    // Save session to backend
    saveSessionMutation.mutate({
      duration: initialMinutes,
      type: mode
    });

    // Save session locally
    LocalStorage.addTimerSession({
      duration: initialMinutes,
      type: mode,
      completedAt: new Date().toISOString()
    });

    // Show completion notification
    if (mode === 'work') {
      toast({
        title: "🎉 Focus session complete!",
        description: `Great job! You focused for ${initialMinutes} minutes.`,
      });
      setSessionsCompleted(prev => prev + 1);
      
      // Auto-start break if enabled
      const data = LocalStorage.getData();
      if (data.preferences.autoStartBreaks) {
        const isLongBreak = (sessionsCompleted + 1) % 4 === 0;
        startBreak(isLongBreak ? 'long_break' : 'short_break');
      } else {
        // Suggest break
        toast({
          title: "Time for a break!",
          description: "Take a short break to recharge.",
        });
      }
    } else {
      toast({
        title: "Break time over!",
        description: "Ready to get back to work?",
      });
      
      // Auto-start work session if enabled
      const data = LocalStorage.getData();
      if (data.preferences.autoStartBreaks) {
        startWork();
      }
    }

    // Play sound if enabled
    const preferences = LocalStorage.getData().preferences;
    if (preferences.soundEnabled) {
      playCompletionSound();
    }
  }, [mode, initialMinutes, sessionsCompleted, saveSessionMutation, toast]);

  const playCompletionSound = () => {
    // Create a simple beep sound using Web Audio API
    try {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 800;
      oscillator.type = 'sine';
      
      gainNode.gain.setValueAtTime(0, audioContext.currentTime);
      gainNode.gain.linearRampToValueAtTime(0.1, audioContext.currentTime + 0.01);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.5);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.5);
    } catch (error) {
      console.log('Audio not supported');
    }
  };

  const start = () => {
    setIsRunning(true);
  };

  const pause = () => {
    setIsRunning(false);
  };

  const reset = () => {
    setIsRunning(false);
    const data = LocalStorage.getData();
    const duration = mode === 'work' ? data.preferences.timerDuration :
                    mode === 'short_break' ? data.preferences.shortBreakDuration :
                    data.preferences.longBreakDuration;
    setMinutes(duration);
    setSeconds(0);
    setInitialMinutes(duration);
  };

  const startWork = () => {
    const data = LocalStorage.getData();
    const duration = data.preferences.timerDuration;
    setMode('work');
    setMinutes(duration);
    setSeconds(0);
    setInitialMinutes(duration);
    setIsRunning(false);
  };

  const startBreak = (breakType: 'short_break' | 'long_break') => {
    const data = LocalStorage.getData();
    const duration = breakType === 'short_break' ? 
      data.preferences.shortBreakDuration : 
      data.preferences.longBreakDuration;
    
    setMode(breakType);
    setMinutes(duration);
    setSeconds(0);
    setInitialMinutes(duration);
    setIsRunning(false);
  };

  // Calculate progress for the circular timer
  const totalSeconds = initialMinutes * 60;
  const currentSeconds = minutes * 60 + seconds;
  const progress = totalSeconds > 0 ? (totalSeconds - currentSeconds) / totalSeconds : 0;

  return {
    minutes,
    seconds,
    isRunning,
    mode,
    progress,
    sessionsCompleted,
    start,
    pause,
    reset,
    startWork,
    startBreak
  };
}
