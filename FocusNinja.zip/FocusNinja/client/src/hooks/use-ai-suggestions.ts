import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { AiSuggestion, InsertAiSuggestion } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

export function useAiSuggestions() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { data: suggestions = [], isLoading, error } = useQuery<AiSuggestion[]>({
    queryKey: ['/api/ai-suggestions']
  });

  const updateSuggestionMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<InsertAiSuggestion> }) => {
      const response = await apiRequest('PUT', `/api/ai-suggestions/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai-suggestions'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error updating suggestion",
        description: error.message || "Failed to update suggestion. Please try again.",
        variant: "destructive",
      });
    }
  });

  const generateSuggestionMutation = useMutation({
    mutationFn: async (context: string = '') => {
      const response = await apiRequest('POST', '/api/ai-suggestions/generate', { context });
      return response.json();
    },
    onSuccess: (newSuggestion) => {
      queryClient.invalidateQueries({ queryKey: ['/api/ai-suggestions'] });
      toast({
        title: "New AI suggestion!",
        description: "Check out your personalized productivity tip.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error generating suggestion",
        description: error.message || "Failed to generate suggestion. Please try again.",
        variant: "destructive",
      });
    }
  });

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest('POST', '/api/ai-chat', { message });
      return response.json();
    },
    onError: (error: any) => {
      toast({
        title: "Chat error",
        description: error.message || "Failed to send message. Please try again.",
        variant: "destructive",
      });
    }
  });

  const updateSuggestion = (id: number, updates: Partial<InsertAiSuggestion>) => {
    updateSuggestionMutation.mutate({ id, updates });
  };

  const generateSuggestion = (context?: string) => {
    generateSuggestionMutation.mutate(context);
  };

  const sendChatMessage = (message: string) => {
    return chatMutation.mutateAsync(message);
  };

  const refreshSuggestions = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/ai-suggestions'] });
  };

  // Filter suggestions by category
  const suggestionsByCategory = {
    motivation: suggestions.filter(s => s.category === 'motivation'),
    productivity: suggestions.filter(s => s.category === 'productivity'),
    wellness: suggestions.filter(s => s.category === 'wellness'),
    learning: suggestions.filter(s => s.category === 'learning')
  };

  // Get recent suggestions (last 5)
  const recentSuggestions = suggestions
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  // Calculate statistics
  const stats = {
    total: suggestions.length,
    helpful: suggestions.filter(s => s.isHelpful === true).length,
    saved: suggestions.filter(s => s.isSaved).length,
    helpfulRate: suggestions.length > 0 ? 
      Math.round((suggestions.filter(s => s.isHelpful === true).length / suggestions.length) * 100) : 0
  };

  return {
    suggestions: recentSuggestions,
    allSuggestions: suggestions,
    suggestionsByCategory,
    isLoading,
    error,
    updateSuggestion,
    generateSuggestion,
    sendChatMessage,
    refreshSuggestions,
    stats,
    isUpdating: updateSuggestionMutation.isPending,
    isGenerating: generateSuggestionMutation.isPending,
    isChatting: chatMutation.isPending
  };
}
