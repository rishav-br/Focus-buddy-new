import { useState } from "react";
import { ChevronUp, Timer, Target, Lightbulb, Home, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function QuickNav() {
  const [isOpen, setIsOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    if (sectionId === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      const element = document.getElementById(sectionId);
      if (element) {
        const offset = 80;
        const elementPosition = element.offsetTop - offset;
        window.scrollTo({ top: elementPosition, behavior: 'smooth' });
      }
    }
    setIsOpen(false);
  };

  const navItems = [
    { id: 'home', label: 'Home', icon: Home, color: 'bg-blue-500 hover:bg-blue-600' },
    { id: 'timer', label: 'Timer', icon: Timer, color: 'bg-green-500 hover:bg-green-600' },
    { id: 'goals', label: 'Goals', icon: Target, color: 'bg-purple-500 hover:bg-purple-600' },
    { id: 'suggestions', label: 'AI Tips', icon: Lightbulb, color: 'bg-orange-500 hover:bg-orange-600' },
  ];

  return (
    <div className="fixed bottom-6 right-6 z-40">
      {/* Quick navigation buttons */}
      {isOpen && (
        <div className="flex flex-col space-y-3 mb-3">
          {navItems.map((item, index) => (
            <Button
              key={item.id}
              onClick={() => scrollToSection(item.id)}
              className={`w-12 h-12 rounded-full ${item.color} text-white shadow-lg hover:shadow-xl transform hover:scale-110 transition-all duration-200 flex items-center justify-center ${isOpen ? 'animate-fadeInUp' : ''}`}
              style={{
                animationDelay: `${index * 0.1}s`
              }}
              title={item.label}
            >
              <item.icon className="w-5 h-5" />
            </Button>
          ))}
        </div>
      )}

      {/* Main toggle button */}
      <Button
        onClick={() => setIsOpen(!isOpen)}
        className={`w-14 h-14 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg hover:shadow-xl transform transition-all duration-300 ${
          isOpen ? 'rotate-45' : 'hover:scale-110'
        }`}
      >
        {isOpen ? (
          <ChevronUp className="w-6 h-6" />
        ) : (
          <Menu className="w-6 h-6" />
        )}
      </Button>


    </div>
  );
}