import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Mail, User, MessageCircle } from "lucide-react";

interface ContactModalProps {
  children: React.ReactNode;
}

export default function ContactModal({ children }: ContactModalProps) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {children}
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-comfortaa text-2xl text-center bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Get in Touch
          </DialogTitle>
        </DialogHeader>
        
        <div className="space-y-6 p-4">
          <div className="text-center">
            <div className="w-20 h-20 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
              <User className="w-10 h-10 text-white" />
            </div>
            <h3 className="font-comfortaa text-xl font-semibold text-gray-900 dark:text-white mb-2">
              Rishav
            </h3>
            <p className="text-gray-600 dark:text-gray-400 font-comfortaa">
              Creator & Developer of Focus Buddy
            </p>
          </div>

          <div className="space-y-4">
            <a
              href="mailto:rishav@example.com"
              className="flex items-center space-x-3 p-4 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-xl hover:shadow-md transition-all duration-200 group"
            >
              <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
                <Mail className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-comfortaa font-medium text-gray-900 dark:text-white">
                  Email
                </div>
                <div className="text-sm text-blue-600 dark:text-blue-400">
                  rishav@example.com
                </div>
              </div>
            </a>

            <div className="flex items-center space-x-3 p-4 bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 rounded-xl">
              <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                <MessageCircle className="w-5 h-5 text-white" />
              </div>
              <div>
                <div className="font-comfortaa font-medium text-gray-900 dark:text-white">
                  Feedback & Support
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  Questions, suggestions, or bug reports
                </div>
              </div>
            </div>
          </div>

          <div className="text-center pt-4 border-t border-gray-200 dark:border-gray-700">
            <p className="text-sm text-gray-600 dark:text-gray-400 font-comfortaa">
              Thanks for using Focus Buddy! Your feedback helps make it better.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}