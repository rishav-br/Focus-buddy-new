import { Clock, Target, Moon, Save, Smartphone, TrendingUp } from "lucide-react";

const features = [
  {
    icon: Clock,
    title: "Smart Timer",
    description: "Adaptive Pomodoro timer that learns your patterns and suggests optimal work intervals.",
    gradient: "gradient-coral-mint"
  },
  {
    icon: Target,
    title: "Goal Tracking",
    description: "Visual progress tracking with celebrations and rewards for achieving milestones.",
    gradient: "gradient-sky-bubblegum"
  },
  {
    icon: Moon,
    title: "Dark Mode",
    description: "Eye-friendly dark theme that automatically adapts to your system preferences.",
    gradient: "gradient-sunny-sage"
  },
  {
    icon: Save,
    title: "Auto Save",
    description: "All your data is automatically saved locally, so you never lose your progress.",
    gradient: "bg-bubblegum"
  },
  {
    icon: Smartphone,
    title: "Responsive",
    description: "Works perfectly on all devices - desktop, tablet, and mobile with touch gestures.",
    gradient: "bg-mint"
  },
  {
    icon: TrendingUp,
    title: "Analytics",
    description: "Detailed insights into your productivity patterns and improvement suggestions.",
    gradient: "bg-sage"
  }
];

export default function FeaturesGrid() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-white/30 dark:bg-space/30 backdrop-blur-sm">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-kalam text-4xl md:text-5xl mb-4">
            <span className="text-6xl animate-stellar">✨</span>{" "}
            <span className="bg-gradient-to-r from-yellow-500 via-orange-500 to-red-500 bg-clip-text text-transparent animate-rainbow">Amazing Features</span>
          </h2>
          <p className="font-comfortaa text-xl text-gray-600 dark:text-gray-300 animate-float">
            Everything you need to supercharge your productivity!
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div 
              key={feature.title}
              className="bg-white dark:bg-midnight rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700 hover:shadow-xl transform hover:scale-105 transition-all duration-300"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className={`w-16 h-16 ${feature.gradient} rounded-2xl flex items-center justify-center mb-4 animate-float`}>
                <feature.icon className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-poppins font-semibold text-xl navy dark:text-white mb-2">
                {feature.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-400">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
