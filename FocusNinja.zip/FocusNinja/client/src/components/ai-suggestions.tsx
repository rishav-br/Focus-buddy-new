import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { ThumbsUp, Bookmark, Send, Lightbulb, Brain } from "lucide-react";
import { useAiSuggestions } from "@/hooks/use-ai-suggestions";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function AiSuggestions() {
  const { suggestions, updateSuggestion, refreshSuggestions } = useAiSuggestions();
  const [chatMessage, setChatMessage] = useState('');
  const [chatResponse, setChatResponse] = useState('');
  const { toast } = useToast();

  const generateSuggestionMutation = useMutation({
    mutationFn: async (context: string = '') => {
      const response = await apiRequest('POST', '/api/ai-suggestions/generate', { context });
      return response.json();
    },
    onSuccess: () => {
      refreshSuggestions();
      toast({
        title: "New suggestion generated!",
        description: "Check out your personalized productivity tip.",
      });
    }
  });

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest('POST', '/api/ai-chat', { message });
      return response.json();
    },
    onSuccess: (data) => {
      setChatResponse(data.response);
    }
  });

  const handleLikeSuggestion = async (suggestionId: number) => {
    await updateSuggestion(suggestionId, { isHelpful: true });
    toast({
      title: "Thanks for the feedback!",
      description: "This helps me provide better suggestions.",
    });
  };

  const handleSaveSuggestion = async (suggestionId: number) => {
    await updateSuggestion(suggestionId, { isSaved: true });
    toast({
      title: "Suggestion saved!",
      description: "You can find it in your saved tips.",
    });
  };

  const handleSendMessage = async () => {
    if (!chatMessage.trim()) return;
    
    chatMutation.mutate(chatMessage);
    setChatMessage('');
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <section id="suggestions" className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-br from-mint/20 via-sky/20 to-bubblegum/20 dark:from-mint/10 dark:via-sky/10 dark:to-bubblegum/10">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-kalam text-4xl md:text-5xl mb-4">
            <span className="text-6xl animate-heartbeat">🤖</span>{" "}
            <span className="bg-gradient-to-r from-cyan-500 via-purple-500 to-pink-500 bg-clip-text text-transparent animate-rainbow">Smart AI Suggestions</span>
          </h2>
          <p className="font-comfortaa text-xl text-gray-600 dark:text-gray-300 animate-float">
            Get personalized tips and motivation from your AI companion!
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-poppins font-semibold text-xl navy dark:text-white">Recent Suggestions</h3>
              <Button
                onClick={() => generateSuggestionMutation.mutate('')}
                disabled={generateSuggestionMutation.isPending}
                className="gradient-coral-mint text-white border-0"
              >
                <Lightbulb className="w-4 h-4 mr-2" />
                {generateSuggestionMutation.isPending ? 'Generating...' : 'Get New Tip'}
              </Button>
            </div>
            
            <div className="space-y-6 mb-8">
              {suggestions.map((suggestion) => (
                <div key={suggestion.id} className="bg-white dark:bg-midnight rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700 transform hover:scale-102 transition-all duration-300">
                  <div className="flex items-start space-x-4">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 animate-pulse-slow ${
                      suggestion.category === 'motivation' ? 'gradient-coral-mint' :
                      suggestion.category === 'productivity' ? 'gradient-sky-bubblegum' :
                      'gradient-sunny-sage'
                    }`}>
                      {suggestion.category === 'productivity' ? (
                        <Brain className="w-6 h-6 text-white" />
                      ) : (
                        <Lightbulb className="w-6 h-6 text-white" />
                      )}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-poppins font-semibold text-lg navy dark:text-white capitalize">
                          {suggestion.category} Tip
                        </h4>
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          {new Date(suggestion.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      <p className="text-gray-600 dark:text-gray-400 mb-3">
                        {suggestion.content}
                      </p>
                      <div className="flex items-center space-x-4">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleLikeSuggestion(suggestion.id)}
                          className={`transition-colors ${suggestion.isHelpful ? 'coral' : 'text-gray-400 hover:text-coral'}`}
                        >
                          <ThumbsUp className="w-4 h-4 mr-1" />
                          Helpful
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleSaveSuggestion(suggestion.id)}
                          className={`transition-colors ${suggestion.isSaved ? 'sky' : 'text-gray-400 hover:text-sky'}`}
                        >
                          <Bookmark className="w-4 h-4 mr-1" />
                          Save
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
              
              {suggestions.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-gray-500 dark:text-gray-400 mb-4">
                    No suggestions yet. Click "Get New Tip" to receive your first AI-powered productivity advice!
                  </p>
                </div>
              )}
            </div>
            
            <div className="bg-white dark:bg-midnight rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700">
              <h4 className="font-poppins font-semibold text-lg navy dark:text-white mb-4">Chat with AI Buddy</h4>
              
              {chatResponse && (
                <div className="bg-gradient-to-br from-mint/10 to-sky/10 rounded-xl p-4 mb-4">
                  <p className="text-gray-700 dark:text-gray-300">{chatResponse}</p>
                </div>
              )}
              
              <div className="flex space-x-2">
                <Input 
                  type="text" 
                  placeholder="Ask me anything about productivity..." 
                  value={chatMessage}
                  onChange={(e) => setChatMessage(e.target.value)}
                  onKeyPress={handleKeyPress}
                  className="flex-1"
                />
                <Button 
                  onClick={handleSendMessage}
                  disabled={chatMutation.isPending || !chatMessage.trim()}
                  className="gradient-coral-mint text-white border-0"
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
              
              {chatMutation.isPending && (
                <div className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                  AI is thinking...
                </div>
              )}
            </div>
          </div>
          
          <div className="text-center">
            <img 
              src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=500" 
              alt="Friendly AI assistant mascot" 
              className="w-full max-w-sm mx-auto rounded-3xl shadow-xl animate-float" 
            />
            
            <div className="grid grid-cols-2 gap-4 mt-8">
              <div className="bg-white/60 dark:bg-midnight/60 backdrop-blur-sm rounded-2xl p-4 text-center border border-white/20">
                <div className="font-fredoka text-2xl coral">{suggestions.length}</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Tips Given</div>
              </div>
              <div className="bg-white/60 dark:bg-midnight/60 backdrop-blur-sm rounded-2xl p-4 text-center border border-white/20">
                <div className="font-fredoka text-2xl mint">
                  {suggestions.filter(s => s.isHelpful).length > 0 ? 
                    Math.round((suggestions.filter(s => s.isHelpful).length / suggestions.length) * 100) : 0}%
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Helpful Rate</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
