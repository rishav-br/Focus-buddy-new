import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { Plus, Trophy, Flame, Star, MoreHorizontal } from "lucide-react";
import { useGoals } from "@/hooks/use-goals";
import { useState } from "react";
import type { Goal } from "@shared/schema";

export default function GoalTracker() {
  const { goals, createGoal, updateGoal, deleteGoal } = useGoals();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [newGoal, setNewGoal] = useState({
    title: '',
    description: '',
    category: '',
    priority: 'medium',
    targetValue: 100
  });

  const handleCreateGoal = async () => {
    if (!newGoal.title || !newGoal.category) return;
    
    await createGoal({
      ...newGoal,
      progress: 0,
      isCompleted: false,
      deadline: null
    });
    
    setNewGoal({
      title: '',
      description: '',
      category: '',
      priority: 'medium',
      targetValue: 100
    });
    setIsDialogOpen(false);
  };

  const handleProgressUpdate = async (goal: Goal, newProgress: number) => {
    await updateGoal(goal.id, { 
      progress: Math.min(100, Math.max(0, newProgress)),
      isCompleted: newProgress >= 100
    });
  };

  const completedGoals = goals.filter(goal => goal.isCompleted).length;
  const streakDays = 12; // This would be calculated based on daily goal completions
  const xpEarned = completedGoals * 100 + goals.reduce((total, goal) => total + goal.progress, 0) * 10;

  return (
    <section id="goals" className="py-20 px-4 sm:px-6 lg:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="font-kalam text-4xl md:text-5xl mb-4">
            <span className="text-6xl animate-bounce-gentle">🎯</span>{" "}
            <span className="bg-gradient-to-r from-green-500 via-blue-500 to-purple-500 bg-clip-text text-transparent animate-rainbow">Goal Tracker</span>
          </h2>
          <p className="font-comfortaa text-xl text-gray-600 dark:text-gray-300 animate-float">
            Set, track, and celebrate your achievements with animated progress!
          </p>
        </div>
        
        <div className="grid lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <h3 className="font-poppins font-semibold text-2xl navy dark:text-white mb-6">Active Goals</h3>
            
            <div className="space-y-4 mb-6">
              {goals.map((goal) => (
                <div key={goal.id} className="bg-white dark:bg-midnight rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700 hover:shadow-xl transition-all duration-300">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 rounded-full animate-pulse ${
                        goal.priority === 'high' ? 'bg-coral' : 
                        goal.priority === 'medium' ? 'bg-sky' : 'bg-sage'
                      }`}></div>
                      <h4 className="font-poppins font-semibold text-lg navy dark:text-white">
                        {goal.title}
                      </h4>
                    </div>
                    <span className="text-sm text-gray-500 dark:text-gray-400">
                      {goal.deadline ? `Due ${new Date(goal.deadline).toLocaleDateString()}` : 'No deadline'}
                    </span>
                  </div>
                  
                  <div className="mb-4">
                    <div className="flex justify-between text-sm text-gray-600 dark:text-gray-400 mb-2">
                      <span>Progress</span>
                      <span>{goal.progress}%</span>
                    </div>
                    <Progress value={goal.progress} className="h-3" />
                  </div>
                  
                  {goal.description && (
                    <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                      {goal.description}
                    </p>
                  )}
                  
                  <div className="flex items-center justify-between">
                    <div className="flex space-x-2">
                      <span className={`px-3 py-1 text-xs rounded-full ${
                        goal.category === 'learning' ? 'bg-coral/20 coral' :
                        goal.category === 'wellness' ? 'bg-sky/20 sky' :
                        goal.category === 'work' ? 'bg-mint/20 mint' :
                        'bg-sage/20 sage'
                      }`}>
                        {goal.category}
                      </span>
                      <span className={`px-3 py-1 text-xs rounded-full ${
                        goal.priority === 'high' ? 'bg-coral/20 coral' :
                        goal.priority === 'medium' ? 'bg-sky/20 sky' :
                        'bg-sage/20 sage'
                      }`}>
                        {goal.priority} priority
                      </span>
                    </div>
                    
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleProgressUpdate(goal, goal.progress + 10)}
                        disabled={goal.progress >= 100}
                      >
                        +10%
                      </Button>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button 
                  className="w-full bg-gradient-to-r from-coral/10 to-mint/10 border-2 border-dashed border-coral/30 rounded-2xl p-6 text-center hover:from-coral/20 hover:to-mint/20 transition-all duration-300 h-auto"
                  variant="ghost"
                >
                  <div className="flex flex-col items-center">
                    <Plus className="w-8 h-8 coral mb-2" />
                    <div className="font-poppins font-semibold coral">Add New Goal</div>
                  </div>
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create New Goal</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="title">Title</Label>
                    <Input
                      id="title"
                      value={newGoal.title}
                      onChange={(e) => setNewGoal({...newGoal, title: e.target.value})}
                      placeholder="Enter goal title"
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Input
                      id="description"
                      value={newGoal.description}
                      onChange={(e) => setNewGoal({...newGoal, description: e.target.value})}
                      placeholder="Optional description"
                    />
                  </div>
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select value={newGoal.category} onValueChange={(value) => setNewGoal({...newGoal, category: value})}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="learning">Learning</SelectItem>
                        <SelectItem value="wellness">Wellness</SelectItem>
                        <SelectItem value="work">Work</SelectItem>
                        <SelectItem value="personal">Personal</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="priority">Priority</Label>
                    <Select value={newGoal.priority} onValueChange={(value) => setNewGoal({...newGoal, priority: value})}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="low">Low</SelectItem>
                        <SelectItem value="medium">Medium</SelectItem>
                        <SelectItem value="high">High</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button onClick={handleCreateGoal} className="w-full gradient-coral-mint text-white border-0">
                    Create Goal
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          
          <div className="space-y-6">
            <img 
              src="https://images.unsplash.com/photo-1513475382585-d06e58bcb0e0?ixlib=rb-4.0.3&auto=format&fit=crop&w=500&h=500" 
              alt="Celebrating mascot with achievements" 
              className="w-full rounded-3xl shadow-xl animate-bounce-gentle" 
            />
            
            <div className="bg-white dark:bg-midnight rounded-2xl p-6 shadow-lg border border-gray-100 dark:border-gray-700">
              <h4 className="font-poppins font-semibold text-lg navy dark:text-white mb-4">This Week</h4>
              
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Trophy className="w-5 h-5 sunny" />
                    <span className="text-gray-600 dark:text-gray-400">Goals Completed</span>
                  </div>
                  <span className="font-semibold navy dark:text-white">{completedGoals}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Flame className="w-5 h-5 coral" />
                    <span className="text-gray-600 dark:text-gray-400">Streak Days</span>
                  </div>
                  <span className="font-semibold navy dark:text-white">{streakDays}</span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Star className="w-5 h-5 bubblegum" />
                    <span className="text-gray-600 dark:text-gray-400">XP Earned</span>
                  </div>
                  <span className="font-semibold navy dark:text-white">{xpEarned.toLocaleString()}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
