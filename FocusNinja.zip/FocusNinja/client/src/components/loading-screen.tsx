import { Brain, Sparkles, Star, Heart } from "lucide-react";

export default function LoadingScreen() {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center overflow-hidden bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 animate-cosmic">
      {/* Animated background particles */}
      <div className="absolute inset-0">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute w-2 h-2 bg-white rounded-full opacity-20 animate-stellar"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 6}s`,
              animationDuration: `${3 + Math.random() * 6}s`
            }}
          />
        ))}
      </div>

      <div className="text-center relative z-10">
        <div className="relative mb-12">
          {/* Outer cosmic ring */}
          <div className="w-48 h-48 mx-auto relative">
            <div className="absolute inset-0 rounded-full bg-gradient-to-r from-pink-500 via-purple-500 to-cyan-500 animate-stellar opacity-20"></div>
            <div className="absolute inset-2 rounded-full bg-gradient-to-r from-yellow-400 via-red-500 to-pink-500 animate-stellar opacity-30" style={{ animationDirection: 'reverse' }}></div>
            
            {/* Main logo container */}
            <div className="absolute inset-8 bg-white rounded-full shadow-2xl animate-morph flex items-center justify-center">
              <div className="relative">
                <Brain className="w-16 h-16 text-purple-600 animate-heartbeat" />
                <Sparkles className="absolute -top-2 -right-2 w-6 h-6 text-yellow-400 animate-wiggle" />
                <Star className="absolute -bottom-1 -left-2 w-4 h-4 text-pink-400 animate-bounce-gentle" />
                <Heart className="absolute top-0 left-8 w-3 h-3 text-red-400 animate-pulse-slow" />
              </div>
            </div>

            {/* Orbiting elements */}
            <div className="absolute inset-0 animate-stellar">
              <div className="absolute top-0 left-1/2 w-4 h-4 bg-yellow-400 rounded-full transform -translate-x-1/2 -translate-y-2 animate-glow"></div>
            </div>
            <div className="absolute inset-0 animate-stellar" style={{ animationDirection: 'reverse', animationDuration: '4s' }}>
              <div className="absolute bottom-0 left-1/2 w-3 h-3 bg-cyan-400 rounded-full transform -translate-x-1/2 translate-y-2 animate-rainbow"></div>
            </div>
          </div>

          {/* Brand name with unique styling */}
          <div className="relative">
            <h1 className="font-righteous text-6xl bg-gradient-to-r from-yellow-400 via-pink-500 to-cyan-400 bg-clip-text text-transparent mb-2 animate-rainbow">
              Focus
            </h1>
            <h1 className="font-kalam text-5xl bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-400 bg-clip-text text-transparent animate-rainbow" style={{ animationDelay: '0.5s' }}>
              Buddy
            </h1>
          </div>

          {/* Tagline */}
          <p className="font-comfortaa text-lg text-white/80 mt-4 animate-float">
            Your AI-Powered Productivity Companion
          </p>

          {/* Unique loading dots */}
          <div className="flex justify-center space-x-3 mt-8">
            <div className="w-4 h-4 bg-gradient-to-r from-pink-400 to-purple-500 rounded-full animate-bounce animate-glow" style={{ animationDelay: "0s" }}></div>
            <div className="w-4 h-4 bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full animate-bounce animate-glow" style={{ animationDelay: "0.2s" }}></div>
            <div className="w-4 h-4 bg-gradient-to-r from-cyan-500 to-yellow-400 rounded-full animate-bounce animate-glow" style={{ animationDelay: "0.4s" }}></div>
            <div className="w-4 h-4 bg-gradient-to-r from-yellow-400 to-pink-400 rounded-full animate-bounce animate-glow" style={{ animationDelay: "0.6s" }}></div>
          </div>

          {/* Loading text */}
          <div className="mt-6">
            <p className="font-patrick text-xl text-white/70 animate-pulse-slow">
              Awakening your focus powers...
            </p>
          </div>
        </div>
      </div>

      {/* Corner decorations */}
      <div className="absolute top-10 left-10 w-8 h-8 bg-yellow-400 rounded-full opacity-30 animate-float"></div>
      <div className="absolute top-20 right-20 w-6 h-6 bg-pink-400 rounded-full opacity-40 animate-bounce-gentle"></div>
      <div className="absolute bottom-16 left-16 w-5 h-5 bg-cyan-400 rounded-full opacity-35 animate-wiggle"></div>
      <div className="absolute bottom-10 right-10 w-7 h-7 bg-purple-400 rounded-full opacity-30 animate-heartbeat"></div>
    </div>
  );
}
