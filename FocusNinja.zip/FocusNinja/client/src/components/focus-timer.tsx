import { Button } from "@/components/ui/button";
import { Play, Pause, Square } from "lucide-react";
import { useTimer } from "@/hooks/use-timer";
import { useQuery } from "@tanstack/react-query";
import type { TimerSession } from "@shared/schema";

export default function FocusTimer() {
  const { 
    minutes, 
    seconds, 
    isRunning, 
    progress, 
    start, 
    pause, 
    reset,
    mode 
  } = useTimer();

  const { data: sessions = [] } = useQuery<TimerSession[]>({
    queryKey: ['/api/timer-sessions']
  });

  const todaySessions = sessions.filter((session) => {
    const today = new Date().toDateString();
    const sessionDate = new Date(session.completedAt).toDateString();
    return today === sessionDate;
  });

  const totalFocusTime = todaySessions.reduce((total: number, session: any) => {
    return total + (session.type === 'work' ? session.duration : 0);
  }, 0);

  const formatTime = (totalMinutes: number) => {
    const hours = Math.floor(totalMinutes / 60);
    const mins = totalMinutes % 60;
    return hours > 0 ? `${hours}h ${mins}m` : `${mins}m`;
  };

  return (
    <section id="timer" className="py-20 px-4 sm:px-6 lg:px-8 bg-white/50 dark:bg-space/30 backdrop-blur-sm">
      <div className="max-w-6xl mx-auto text-center">
        <h2 className="font-kalam text-4xl md:text-5xl mb-4">
          <span className="text-6xl animate-wiggle">🍅</span>{" "}
          <span className="bg-gradient-to-r from-red-500 via-orange-500 to-yellow-500 bg-clip-text text-transparent animate-rainbow">Focus Timer</span>
        </h2>
        <p className="font-comfortaa text-xl text-gray-600 dark:text-gray-300 mb-12 animate-float">
          Boost productivity with Pomodoro technique and your AI buddy!
        </p>
        
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="order-2 md:order-1">
            <div className="bg-white dark:bg-midnight rounded-3xl p-8 shadow-2xl border border-gray-100 dark:border-gray-700">
              <div className="relative w-64 h-64 mx-auto mb-8">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 120 120">
                  <circle 
                    cx="60" 
                    cy="60" 
                    r="50" 
                    stroke="#f0f0f0" 
                    strokeWidth="8" 
                    fill="none"
                  />
                  <circle 
                    cx="60" 
                    cy="60" 
                    r="50" 
                    stroke="url(#gradient)" 
                    strokeWidth="8" 
                    fill="none"
                    strokeLinecap="round" 
                    strokeDasharray="314" 
                    strokeDashoffset={314 - (progress * 314)}
                    className="transition-all duration-1000 ease-in-out"
                  />
                  <defs>
                    <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                      <stop offset="0%" stopColor="hsl(4, 100%, 69%)" />
                      <stop offset="100%" stopColor="hsl(176, 68%, 57%)" />
                    </linearGradient>
                  </defs>
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="font-fredoka text-4xl navy dark:text-white">
                    {String(minutes).padStart(2, '0')}:{String(seconds).padStart(2, '0')}
                  </span>
                  <span className="font-poppins text-lg text-gray-500 capitalize">
                    {mode === 'work' ? 'Focus Time' : mode === 'short_break' ? 'Short Break' : 'Long Break'}
                  </span>
                </div>
              </div>
              
              <div className="flex justify-center space-x-4">
                <Button 
                  onClick={isRunning ? pause : start}
                  className="gradient-coral-mint text-white p-4 rounded-full hover:shadow-lg transform hover:scale-110 transition-all duration-200 border-0"
                >
                  {isRunning ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5" />}
                </Button>
                <Button 
                  onClick={reset}
                  variant="secondary"
                  className="p-4 rounded-full hover:shadow-lg transform hover:scale-110 transition-all duration-200"
                >
                  <Square className="w-5 h-5" />
                </Button>
              </div>
            </div>
          </div>
          
          <div className="order-1 md:order-2">
            <img 
              src="https://images.unsplash.com/photo-1434494878577-86c23bcb06b9?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=600" 
              alt="Focused mascot with headphones" 
              className="w-full max-w-sm mx-auto rounded-3xl shadow-xl animate-float" 
            />
            
            <div className="grid grid-cols-2 gap-4 mt-8">
              <div className="bg-gradient-to-br from-coral/20 to-coral/10 dark:from-coral/30 dark:to-coral/20 rounded-2xl p-4 text-center border border-coral/20">
                <div className="font-fredoka text-2xl coral">
                  {todaySessions.length}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Sessions Today</div>
              </div>
              <div className="bg-gradient-to-br from-mint/20 to-mint/10 dark:from-mint/30 dark:to-mint/20 rounded-2xl p-4 text-center border border-mint/20">
                <div className="font-fredoka text-2xl mint">
                  {formatTime(totalFocusTime)}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Focus Time</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
