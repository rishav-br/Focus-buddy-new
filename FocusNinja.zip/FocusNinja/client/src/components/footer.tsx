import { Brain } from "lucide-react";
import { Button } from "@/components/ui/button";
import ContactModal from "./contact-modal";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="py-16 px-4 sm:px-6 lg:px-8 bg-navy dark:bg-midnight text-white">
      <div className="max-w-6xl mx-auto">
        <div className="grid md:grid-cols-4 gap-8 mb-8">
          <div className="md:col-span-2">
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 gradient-coral-mint rounded-full flex items-center justify-center animate-float">
                <Brain className="w-6 h-6 text-white" />
              </div>
              <span className="font-righteous text-2xl bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">Focus Buddy</span>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Your AI-powered productivity companion that makes focusing fun and rewarding. Join thousands of users who've transformed their productivity!
            </p>
            <div className="flex space-x-4">
              <Button variant="ghost" size="icon" className="w-10 h-10 bg-white/10 rounded-full hover:bg-white/20 transition-colors">
                <span className="text-lg">🐦</span>
              </Button>
              <Button variant="ghost" size="icon" className="w-10 h-10 bg-white/10 rounded-full hover:bg-white/20 transition-colors">
                <span className="text-lg">📱</span>
              </Button>
              <Button variant="ghost" size="icon" className="w-10 h-10 bg-white/10 rounded-full hover:bg-white/20 transition-colors">
                <span className="text-lg">💬</span>
              </Button>
            </div>
          </div>
          
          <div>
            <h4 className="font-poppins font-semibold text-lg mb-4">Features</h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <button 
                  onClick={() => scrollToSection('timer')}
                  className="hover:text-coral transition-colors text-left"
                >
                  Focus Timer
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('goals')}
                  className="hover:text-coral transition-colors text-left"
                >
                  Goal Tracking
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('suggestions')}
                  className="hover:text-coral transition-colors text-left"
                >
                  AI Suggestions
                </button>
              </li>
              <li>
                <span className="hover:text-coral transition-colors cursor-pointer">Analytics</span>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-comfortaa font-semibold text-lg mb-4">Contact & Support</h4>
            <ul className="space-y-2 text-gray-300">
              <li>
                <div className="font-comfortaa font-medium text-purple-300">Developed by Rishav</div>
              </li>
              <li>
                <ContactModal>
                  <button className="text-gray-300 hover:text-purple-400 transition-colors font-comfortaa text-sm text-left">
                    Contact Me
                  </button>
                </ContactModal>
              </li>
              <li><span className="hover:text-purple-400 transition-colors cursor-pointer text-sm">Help Center</span></li>
              <li><span className="hover:text-purple-400 transition-colors cursor-pointer text-sm">Privacy Policy</span></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 pt-8 text-center">
          <p className="text-gray-400 font-comfortaa">
            &copy; 2024 Focus Buddy. Crafted with passion by Rishav for productive humans everywhere.
          </p>
        </div>
      </div>
    </footer>
  );
}
