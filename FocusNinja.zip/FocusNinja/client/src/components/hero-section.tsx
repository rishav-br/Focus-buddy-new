import { Button } from "@/components/ui/button";
import { Play, Info } from "lucide-react";

export default function HeroSection() {
  const scrollToTimer = () => {
    const timerSection = document.getElementById('timer');
    if (timerSection) {
      timerSection.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section className="pt-24 pb-16 px-4 sm:px-6 lg:px-8 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="font-righteous text-5xl md:text-6xl lg:text-7xl mb-6 leading-tight">
              <span className="bg-gradient-to-r from-purple-600 via-pink-600 to-cyan-600 bg-clip-text text-transparent animate-rainbow">Stay</span>{" "}
              <span className="bg-gradient-to-r from-yellow-500 via-red-500 to-pink-500 bg-clip-text text-transparent animate-rainbow" style={{ animationDelay: '0.5s' }}>Focused</span>{" "}
              <span className="bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500 bg-clip-text text-transparent animate-rainbow" style={{ animationDelay: '1s' }}>with AI</span>
            </h1>
            <p className="font-comfortaa text-xl text-gray-600 dark:text-gray-300 mb-8 leading-relaxed animate-float">
              Meet your personal productivity companion! Track goals, manage time, and get smart AI suggestions with adorable mascot friends.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                onClick={scrollToTimer}
                className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-comfortaa font-semibold py-4 px-8 rounded-2xl hover:shadow-xl transform hover:scale-105 transition-all duration-300 animate-glow border-0"
              >
                <Play className="w-4 h-4 mr-2" />
                Start Focusing
              </Button>
              <Button 
                variant="outline"
                className="bg-white dark:bg-gray-800 text-purple-600 dark:text-purple-400 font-comfortaa font-semibold py-4 px-8 rounded-2xl border-2 border-purple-500 hover:bg-purple-500 hover:text-white transition-all duration-300 animate-heartbeat"
              >
                <Info className="w-4 h-4 mr-2" />
                Learn More
              </Button>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="https://images.unsplash.com/photo-1485827404703-89b55fcc595e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=800" 
              alt="Friendly AI mascot character" 
              className="w-full max-w-md mx-auto rounded-3xl shadow-2xl animate-float" 
            />
            
            <div className="absolute -top-4 -right-4 w-16 h-16 bg-sunny rounded-full flex items-center justify-center animate-bounce-gentle shadow-lg">
              <span className="text-white text-xl">💡</span>
            </div>
            <div className="absolute -bottom-4 -left-4 w-12 h-12 bg-bubblegum rounded-full flex items-center justify-center animate-pulse shadow-lg">
              <span className="text-white">❤️</span>
            </div>
            <div className="absolute top-1/2 -right-8 w-10 h-10 bg-sky rounded-full flex items-center justify-center animate-wiggle shadow-lg">
              <span className="text-white text-sm">⭐</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
